function phonenumber(inputtxt)
{
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if(inputtxt.value.match(phoneno))
    {
        return true;
    }
    else
    {
        alert("phone number is not correct");
        return false;
    }

}

function ValidateEmail(inputText)
{
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(inputText.value.match(mailformat))
    {
        document.form2.text2.focus();
        return true;
    }
    else
    {
        alert("You have entered an invalid email address!");
        document.form2.text2.focus();
        return false;
    }
}

function ValidateIPaddress(inputText)
{
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if(inputText.value.match(ipformat))
    {
        document.form13.text3.focus();
        return true;
    }
    else
    {
        alert("You have entered an invalid IP address!");
        document.form3.text3.focus();return false;
    }
}